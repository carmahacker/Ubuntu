CREATE TABLE IF NOT EXISTS clients (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    remarks TEXT,
    uuid TEXT NOT NULL,
    status BOOLEAN DEFAULT TRUE
);
