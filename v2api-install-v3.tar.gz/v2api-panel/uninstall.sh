#!/bin/bash
systemctl stop myapi || true
systemctl stop v2ray-reload.path || true

systemctl disable myapi || true
systemctl disable v2ray-reload.path || true

rm -f /etc/systemd/system/myapi.service
rm -f /etc/systemd/system/v2ray-reload.path
rm -f /etc/systemd/system/v2ray-reload.service

systemctl daemon-reload

rm -rf /opt/v2api-panel
rm -f /etc/nginx/sites-enabled/v2api.conf
rm -f /etc/nginx/sites-available/v2api.conf

systemctl reload nginx || true

echo "Удалено."
