import os
import json
import uuid
import logging
from contextlib import contextmanager
from typing import Optional, List, Any

from flask import Flask, jsonify, request, Response
from flask_cors import CORS
import psycopg2
from psycopg2.pool import SimpleConnectionPool
from psycopg2.extras import RealDictCursor

from pydantic import BaseModel, ValidationError, constr
from pythonjsonlogger import jsonlogger


# ----------------------------
# ЛОГИРОВАНИЕ (JSON формат)
# ----------------------------

logger = logging.getLogger("v2api")
logger.setLevel(logging.INFO)

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)


# ----------------------------
# НАСТРОЙКИ
# ----------------------------

API_TOKEN_PATH = "/opt/v2api/api_token"

try:
    API_TOKEN = open(API_TOKEN_PATH, "r").read().strip()
    if not API_TOKEN:
        raise ValueError("API token is empty")
except Exception as e:
    logger.critical("Failed to read API token from %s: %s", API_TOKEN_PATH, e)
    raise SystemExit(1)

DB_CONFIG = {
    "dbname": "v2ray_db",
    "user": "v2ray_user",
    "password": API_TOKEN,
    "host": "localhost",
    "port": 5432,
}

V2RAY_CONFIG = "/usr/local/etc/v2ray/config.json"
V2RAY_RELOAD_FLAG = "/run/v2ray/reload.flag"

MAX_REQUEST_SIZE_MB = 1

# ----------------------------
# Pydantic-схемы
# ----------------------------

NameType = constr(strip_whitespace=True, min_length=1, max_length=64)
CommentType = constr(strip_whitespace=True, max_length=256)


class ClientCreate(BaseModel):
    name: NameType
    comment: Optional[CommentType] = ""


class ClientUpdate(BaseModel):
    name: Optional[NameType] = None
    status: Optional[bool] = None
    comment: Optional[CommentType] = None


class ClientRow(BaseModel):
    id: int
    name: str
    comment: str
    uuid: str
    status: bool


# ----------------------------
# Flask + CORS
# ----------------------------

app = Flask(__name__)
CORS(app, supports_credentials=True)
app.config["MAX_CONTENT_LENGTH"] = MAX_REQUEST_SIZE_MB * 1024 * 1024


# ----------------------------
# Пул соединений PostgreSQL
# ----------------------------

POOL: Optional[SimpleConnectionPool] = None


def init_db_pool() -> None:
    global POOL
    if POOL is None:
        logger.info("Initializing PostgreSQL connection pool")
        POOL = SimpleConnectionPool(
            minconn=1,
            maxconn=10,
            **DB_CONFIG,
        )


@contextmanager
def get_db_connection():
    """
    Контекстный менеджер, возвращающий conn из пула
    """
    if POOL is None:
        init_db_pool()
    assert POOL is not None
    conn = POOL.getconn()
    try:
        yield conn
    finally:
        POOL.putconn(conn)


# ----------------------------
# Вспомогательные функции
# ----------------------------

def check_auth(req) -> bool:
    token = req.headers.get("Authorization", "").replace("Bearer ", "", 1)
    return token == API_TOKEN


def error_response(message: str, status_code: int = 400):
    logger.warning("Error %s: %s", status_code, message)
    return jsonify({"error": message}), status_code


def mark_v2ray_reload_needed() -> None:
    """
    Создаёт флаг-файл, который отслеживает v2ray-reload.path
    """
    try:
        os.makedirs(os.path.dirname(V2RAY_RELOAD_FLAG), exist_ok=True)
        with open(V2RAY_RELOAD_FLAG, "w") as f:
            f.write("reload\n")
        logger.info("V2Ray reload flag written to %s", V2RAY_RELOAD_FLAG)
    except Exception as e:
        logger.error("Failed to write V2Ray reload flag: %s", e)


def build_vmess_clients() -> List[dict]:
    """
    Читает всех активных клиентов (status = TRUE) и возвращает список
    vmess-клиентов для V2Ray.
    """
    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT uuid, name FROM clients WHERE status = TRUE ORDER BY id;"
            )
            rows: List[dict] = cur.fetchall()

    vmess_clients = [
        {
            "id": row["uuid"],
            "alterId": 0,
            "level": 0,
            "email": row["name"],
        }
        for row in rows
    ]
    logger.info("Built %d vmess clients from DB", len(vmess_clients))
    return vmess_clients


def update_v2ray_config() -> None:
    """
    Полная генерация config.json для V2Ray на основе текущих данных в БД.
    Запись атомарная: сначала во временный файл, затем os.replace().
    """
    clients = build_vmess_clients()

    new_config: dict[str, Any] = {
        "configFormat": "json",
        "log": {
            "access": "/var/log/v2ray/access.log",
            "error": "/var/log/v2ray/error.log",
            "loglevel": "warning",
        },
        "api": {
            "tag": "api",
            "services": ["HandlerService", "LoggerService", "StatsService"],
        },
        "stats": {},
        "dns": {},
        "policy": {
            "levels": {
                "0": {
                    "handshake": 6,
                    "connIdle": 240,
                    "uplinkOnly": 1,
                    "downlinkOnly": 4,
                    "statsUserUplink": True,
                    "statsUserDownlink": True,
                }
            },
            "system": {
                "statsInboundUplink": True,
                "statsInboundDownlink": True,
                "statsOutboundUplink": True,
                "statsOutboundDownlink": True,
            },
        },
        "routing": {
            "domainStrategy": "AsIs",
            "rules": [
                {
                    "type": "field",
                    "inboundTag": ["api"],
                    "outboundTag": "api",
                }
            ],
        },
        "inbounds": [
            {
                "tag": "vmess_ws",
                "listen": "127.0.0.1",
                "port": 10085,
                "protocol": "vmess",
                "settings": {
                    "clients": clients,
                },
                "streamSettings": {
                    "network": "ws",
                    "wsSettings": {
                        "path": "/vmess",
                    },
                },
            },
            {
                "tag": "api",
                "listen": "127.0.0.1",
                "port": 52018,
                "protocol": "dokodemo-door",
                "settings": {
                    "address": "127.0.0.1",
                },
            },
        ],
        "outbounds": [
            {
                "tag": "direct",
                "protocol": "freedom",
            },
            {
                "tag": "block",
                "protocol": "blackhole",
            },
        ],
    }

    tmp_path = f"{V2RAY_CONFIG}.tmp"
    try:
        os.makedirs(os.path.dirname(V2RAY_CONFIG), exist_ok=True)
        with open(tmp_path, "w") as f:
            json.dump(new_config, f, indent=4)
        os.replace(tmp_path, V2RAY_CONFIG)
        logger.info("V2Ray config updated at %s", V2RAY_CONFIG)
        mark_v2ray_reload_needed()
    except Exception as e:
        logger.error("Failed to write V2Ray config: %s", e)
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


# ----------------------------
# Глобальные хуки и обработчики
# ----------------------------

@app.before_request
def secure():
    # CORS preflight
    if request.method == "OPTIONS":
        return None

    # Логирование запроса
    logger.info(
        "Incoming request",
        extra={
            "path": request.path,
            "method": request.method,
            "remote_addr": request.remote_addr,
        },
    )

    # Авторизация только для /api/*
    if request.path.startswith("/api") and not check_auth(request):
        return error_response("Unauthorized", 401)


@app.errorhandler(ValidationError)
def handle_validation_error(err: ValidationError):
    return error_response(str(err), 400)


@app.errorhandler(404)
def handle_404(err):
    return error_response("Not Found", 404)


@app.errorhandler(500)
def handle_500(err):
    logger.exception("Internal server error: %s", err)
    return error_response("Internal Server Error", 500)


# ----------------------------
# API-эндпоинты
# ----------------------------

@app.route("/api/clients", methods=["GET"])
def get_clients():
    """
    Вернуть список клиентов в том же формате, что и раньше:
    [[id, name, comment, uuid, status], ...]
    """
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, name, comment, uuid, status FROM clients ORDER BY id;")
            rows = cur.fetchall()

    return jsonify(rows)


@app.route("/api/clients", methods=["POST"])
def add_client():
    """
    Создать клиента и обновить V2Ray config.
    """
    try:
        payload = request.get_json(force=True, silent=False)
    except Exception:
        return error_response("Invalid JSON", 400)

    try:
        data = ClientCreate(**(payload or {}))
    except ValidationError as e:
        return handle_validation_error(e)

    uid = str(uuid.uuid4())

    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO clients (name, comment, uuid, status)
                VALUES (%s, %s, %s, TRUE)
                RETURNING id;
                """,
                (data.name, data.comment or "", uid),
            )
            _ = cur.fetchone()
        conn.commit()

    update_v2ray_config()

    return jsonify({"uuid": uid, "name": data.name})


@app.route("/api/clients/<int:cid>", methods=["PUT"])
def update_client(cid: int):
    """
    Обновить имя/комментарий/статус клиента по id.
    """
    try:
        payload = request.get_json(force=True, silent=False)
    except Exception:
        return error_response("Invalid JSON", 400)

    try:
        data = ClientUpdate(**(payload or {}))
    except ValidationError as e:
        return handle_validation_error(e)

    fields = []
    params: list[Any] = []

    if data.name is not None:
        fields.append("name = %s")
        params.append(data.name)

    if data.comment is not None:
        fields.append("comment = %s")
        params.append(data.comment)

    if data.status is not None:
        fields.append("status = %s")
        params.append(data.status)

    if not fields:
        return error_response("nothing to update", 400)

    params.append(cid)

    sql = "UPDATE clients SET " + ", ".join(fields) + " WHERE id = %s RETURNING uuid;"

    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, tuple(params))
            res = cur.fetchone()
        conn.commit()

    if not res:
        return error_response("not found", 404)

    update_v2ray_config()
    return jsonify({"id": cid})


@app.route("/api/clients/<int:cid>", methods=["DELETE"])
def delete_client(cid: int):
    """
    Удалить клиента по id.
    """
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM clients WHERE id = %s RETURNING uuid;", (cid,))
            res = cur.fetchone()
        conn.commit()

    if not res:
        return error_response("not found", 404)

    update_v2ray_config()
    return Response(status=204)


@app.route("/api/logs", methods=["GET"])
def get_logs():
    """
    Просто отдаём access.log V2Ray (если есть).
    """
    log_path = "/var/log/v2ray/access.log"
    try:
        with open(log_path, "r") as f:
            return Response(f.read(), mimetype="text/plain")
    except FileNotFoundError:
        return error_response("log not found", 404)
    except Exception as e:
        logger.error("Error reading log file %s: %s", log_path, e)
        return error_response("failed to read log", 500)


@app.route("/api/status", methods=["GET"])
def get_status():
    """
    Простой health-check API / БД / файлов.
    """
    db_ok = False
    db_error = None
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
                _ = cur.fetchone()
        db_ok = True
    except Exception as e:
        db_error = str(e)
        logger.error("DB health check failed: %s", e)

    status = {
        "db": "ok" if db_ok else "error",
        "db_error": db_error,
        "v2ray_config_exists": os.path.exists(V2RAY_CONFIG),
        "reload_flag_exists": os.path.exists(V2RAY_RELOAD_FLAG),
    }
    return jsonify(status)


# ----------------------------
# Точка входа (для debug)
# ----------------------------

if __name__ == "__main__":
    init_db_pool()
    app.run(host="0.0.0.0", port=8081, debug=False)
