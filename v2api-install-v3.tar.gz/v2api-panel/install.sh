#!/bin/bash
set -e

INSTALL_DIR="/opt/v2api-panel"
APP_DIR="$INSTALL_DIR"
V2RAY_CFG="/usr/local/etc/v2ray/config.json"

echo "=============================================="
echo "   V2Ray + API + PostgreSQL + Nginx installer"
echo "=============================================="

# ---------------------------------------------------------
# ASK DOMAIN
# ---------------------------------------------------------
echo -n "Введите доменное имя (например: v2.example.com): "
read DOMAIN

if [[ -z "$DOMAIN" ]]; then
    echo "Ошибка: домен пустой"
    exit 1
fi

echo "Домен: $DOMAIN"
sleep 1

# ---------------------------------------------------------
# SYSTEM UPDATE
# ---------------------------------------------------------
apt update -y
apt install -y curl wget unzip jq nano software-properties-common

# ---------------------------------------------------------
# INSTALL PYTHON & POSTGRES
# ---------------------------------------------------------
apt install -y python3 python3-venv python3-pip postgresql postgresql-contrib

# ---------------------------------------------------------
# CREATE SYSTEM USER
# ---------------------------------------------------------
if ! id "v2api" >/dev/null 2>&1; then
    useradd -r -s /bin/false v2api
fi

mkdir -p "$INSTALL_DIR"
cp -r . "$INSTALL_DIR"
chown -R v2api:v2api "$INSTALL_DIR"

# ---------------------------------------------------------
# PYTHON VENV
# ---------------------------------------------------------
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"

# ---------------------------------------------------------
# GENERATE API TOKEN
# ---------------------------------------------------------
API_TOKEN=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32)
echo "$API_TOKEN" > "$INSTALL_DIR/api_token"
chmod 600 "$INSTALL_DIR/api_token"
chown v2api:v2api "$INSTALL_DIR/api_token"

echo "API токен: $API_TOKEN"

# ---------------------------------------------------------
# PostgreSQL Setup
# ---------------------------------------------------------
DB_PASS=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 24)

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='v2ray_db'" | grep -q 1 ||
sudo -u postgres psql -c "CREATE DATABASE v2ray_db;"

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='v2ray_user'" | grep -q 1 ||
sudo -u postgres psql -c "CREATE USER v2ray_user WITH PASSWORD '$DB_PASS';"

sudo -u postgres psql -c "GRANT CONNECT ON DATABASE v2ray_db TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT USAGE ON SCHEMA public TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO v2ray_user;"

sudo -u postgres psql -d v2ray_db -c "
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO v2ray_user;"

sudo -u postgres psql -d v2ray_db -c "
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT USAGE,SELECT ON SEQUENCES TO v2ray_user;"

# ---------------------------------------------------------
# Create Table
# ---------------------------------------------------------
SQL_FILE="$INSTALL_DIR/sql/init.sql"
echo "=== Создаю таблицу clients ==="
sudo -u postgres psql -d v2ray_db -f "$SQL_FILE"

# ---------------------------------------------------------
# INSTALL V2RAY
# ---------------------------------------------------------
echo "=== Installing latest stable V2Ray ==="

LATEST=$(curl -s https://api.github.com/repos/v2fly/v2ray-core/releases/latest | jq -r '.tag_name')

bash <(curl -L -s https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) --version "$LATEST"

systemctl enable v2ray
systemctl start v2ray

# ---------------------------------------------------------
# Prepare reload directory
# ---------------------------------------------------------
mkdir -p /run/v2ray
chown v2api:v2api /run/v2ray
chmod 775 /run/v2ray

# ---------------------------------------------------------
# SYSTEMD UNITS
# ---------------------------------------------------------
cp "$INSTALL_DIR/systemd/myapi.service" /etc/systemd/system/
cp "$INSTALL_DIR/systemd/v2ray-reload.path" /etc/systemd/system/
cp "$INSTALL_DIR/systemd/v2ray-reload.service" /etc/systemd/system/

systemctl daemon-reload
systemctl enable myapi
systemctl enable v2ray-reload.path
systemctl start myapi
systemctl start v2ray-reload.path

# ---------------------------------------------------------
# NGINX + CERTBOT
# ---------------------------------------------------------
apt install -y nginx certbot python3-certbot-nginx

cp "$INSTALL_DIR/nginx/v2api.conf.template" /etc/nginx/sites-available/v2api.conf
sed -i "s/DOMAIN/$DOMAIN/g" /etc/nginx/sites-available/v2api.conf

ln -sf /etc/nginx/sites-available/v2api.conf /etc/nginx/sites-enabled/v2api.conf

nginx -t
systemctl restart nginx

echo "=== Запрашиваю Let's Encrypt SSL ==="
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m admin@$DOMAIN

systemctl reload nginx

# ---------------------------------------------------------
# DONE
# ---------------------------------------------------------
echo "=============================================="
echo "   УСТАНОВКА ЗАВЕРШЕНА!"
echo "=============================================="
echo "API URL: https://$DOMAIN/api/"
echo "API TOKEN: $API_TOKEN"
echo "VMESS WS: wss://$DOMAIN/vmess"
echo "----------------------------------------------"
echo "Файл токена: $INSTALL_DIR/api_token"
echo "Пароль БД: $DB_PASS"
echo "----------------------------------------------"
echo "Готово."
