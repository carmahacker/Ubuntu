#!/bin/bash
set -e

echo "=============================================="
echo "   V2Ray + API + PostgreSQL + Nginx installer"
echo "=============================================="

# ---------------------------------------------------------
# ASK DOMAIN
# ---------------------------------------------------------
echo -n "Введите доменное имя (например: v2.example.com): "
read DOMAIN

if [[ -z "$DOMAIN" ]]; then
    echo "Ошибка: домен пустой"
    exit 1
fi

echo "Домен: $DOMAIN"
sleep 1

# ---------------------------------------------------------
# SYSTEM UPDATE
# ---------------------------------------------------------
apt update -y
apt install -y curl wget unzip jq nano software-properties-common

# ---------------------------------------------------------
# INSTALL PYTHON & POSTGRES
# ---------------------------------------------------------
apt install -y python3 python3-venv python3-pip postgresql postgresql-contrib

# ---------------------------------------------------------
# CREATE SYSTEM USER
# ---------------------------------------------------------
if ! id "v2api" >/dev/null 2>&1; then
    useradd -r -s /bin/false v2api
fi

mkdir -p /opt/v2api
cp app.py /opt/v2api/
cp requirements.txt /opt/v2api/
chown -R v2api:v2api /opt/v2api

# ---------------------------------------------------------
# PYTHON VENV
# ---------------------------------------------------------
python3 -m venv /opt/v2api/venv
/opt/v2api/venv/bin/pip install --upgrade pip
/opt/v2api/venv/bin/pip install -r /opt/v2api/requirements.txt

# ---------------------------------------------------------
# GENERATE API TOKEN
# ---------------------------------------------------------
API_TOKEN=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32)
echo "$API_TOKEN" > /opt/v2api/api_token
chmod 600 /opt/v2api/api_token
chown v2api:v2api /opt/v2api/api_token

echo "API токен: $API_TOKEN"

# ---------------------------------------------------------
# SETUP POSTGRESQL
# ---------------------------------------------------------
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='v2ray_db'" | grep -q 1 ||
sudo -u postgres psql -c "CREATE DATABASE v2ray_db TEMPLATE template0 LC_COLLATE='C.UTF-8' LC_CTYPE='C.UTF-8';"

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='v2ray_user'" | grep -q 1 ||
sudo -u postgres psql -c "CREATE USER v2ray_user WITH PASSWORD '$API_TOKEN';"

sudo -u postgres psql -c "GRANT CONNECT ON DATABASE v2ray_db TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT USAGE ON SCHEMA public TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO v2ray_user;"
sudo -u postgres psql -d v2ray_db -c "
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT USAGE,SELECT ON SEQUENCES TO v2ray_user;"

# TABLE
sudo -u postgres psql -d v2ray_db -f sql/init.sql

# ---------------------------------------------------------
# INSTALL V2RAY
# ---------------------------------------------------------
echo "=== Installing latest stable V2Ray ==="

bash <(curl -Ls https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) --version latest

systemctl enable v2ray
systemctl start v2ray

# ---------------------------------------------------------
# PREPARE CONFIG PATHS
# ---------------------------------------------------------
mkdir -p /run/v2ray
chown v2api:v2api /run/v2ray
chmod 775 /run/v2ray

# ---------------------------------------------------------
# INSTALL SYSTEMD UNITS
# ---------------------------------------------------------
cp systemd/myapi.service /etc/systemd/system/
cp systemd/v2ray-reload.path /etc/systemd/system/
cp systemd/v2ray-reload.service /etc/systemd/system/

systemctl daemon-reload
systemctl enable myapi
systemctl enable v2ray-reload.path
systemctl start myapi
systemctl start v2ray-reload.path

# ---------------------------------------------------------
# INSTALL NGINX + CERTBOT
# ---------------------------------------------------------
apt install -y nginx certbot python3-certbot-nginx

cp nginx/v2api.conf.template /etc/nginx/sites-available/v2api.conf
sed -i "s/DOMAIN/$DOMAIN/g" /etc/nginx/sites-available/v2api.conf

ln -sf /etc/nginx/sites-available/v2api.conf /etc/nginx/sites-enabled/v2api.conf

nginx -t
systemctl restart nginx

echo "=== Запрашиваю Let's Encrypt SSL ==="
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m admin@$DOMAIN

# ---------------------------------------------------------
# RELOAD NGINX WITH SSL
# ---------------------------------------------------------
sed -i "s/DOMAIN/$DOMAIN/g" /etc/nginx/sites-available/v2api.conf
nginx -t && systemctl reload nginx

# ---------------------------------------------------------
# DONE
# ---------------------------------------------------------
echo "=============================================="
echo "   УСТАНОВКА ЗАВЕРШЕНА!"
echo "=============================================="
echo "API URL: https://$DOMAIN/api/"
echo "API TOKEN: $API_TOKEN"
echo "VMESS WS: wss://$DOMAIN/vmess"
echo "----------------------------------------------"
echo "Файл токена: /opt/v2api/api_token"
echo "DB: v2ray_db / user: v2ray_user"
echo "----------------------------------------------"
echo "Готово."
